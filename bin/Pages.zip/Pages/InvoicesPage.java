package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InvoicesPage extends PageObject {

	@FindBy(xpath = "//*[@id=\"app\"]/div[14]/main/div/div/div[1]/div/div[1]/h4")
	WebElement invoicesListText;

	@FindBy(xpath = "//*[@id=\"app\"]/div[14]/main/div/div/div[1]/div/div[2]/div/div/div[1]/div/div/div[1]/div/div/div/div[2]/div/i")
	WebElement clientList;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[11]/div/div/div[3]/a/div/div")
	WebElement ivanMarkovic;

	@FindBy(id = "filter-from")
	WebElement fromDate;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/table/tbody/tr[1]/td[4]/button/div")
	WebElement date1;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/table/tbody/tr[4]/td[3]/button/div")
	WebElement date24;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/table/tbody/tr[2]/td[4]/button/div")
	WebElement date8;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[1]/button[1]/div/i")
	WebElement fromLastMonth;
	
	@FindBy(id = "filter-from-ok")
	WebElement from_ok;

	@FindBy(id = "filter-to")
	WebElement toDate;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/table/tbody/tr[1]/td[4]/button/div")
	WebElement dateTo1;
	
	@FindBy(id = "filter-to-ok")
	WebElement to_ok;

	@FindBy(xpath = "//*[@id=\"filter-period\"]/div/i")
	WebElement monthButton;

	@FindBy(id = "this-month")
	WebElement thisMonth;

	@FindBy(id = "last-month")
	WebElement lastMonth;

	@FindBy(id = "reset-dates")
	WebElement resetDates;

	@FindBy(xpath = "//*[@id=\"filter-reset\"]/div/i")
	WebElement refresh;
	
	@FindBy(xpath = "//*[@id=\"inv-status-btn-2018-MKO1\"]/div/i[1]")
	WebElement changeStatusButton;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[16]/main/div/div/div[2]/div/div[2]/div/div[5]/div/div[2]/div/div/div[1]/div/div/div/div[2]/div/i")
	WebElement changeStatusDropDown;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[10]/div/div/div[2]/a/div/div")
	WebElement sent;
	
	@FindBy(id = "inv-status-dialog-yes-2018-MKO1")
	WebElement sentYes;
	
	@FindBy(id = "inv-status-dialog-no-2018-MKO1")
	WebElement sentNo;

	@FindBy(xpath = "//*[@id=\"context-257\"]/div/i")
	WebElement optionsButton;

	@FindBy(xpath = "//*[@id=\"context-edit-257\"]/div/i")
	WebElement editButton;

	@FindBy(xpath = "//*[@id=\"context-preview-257\"]/div/i")
	WebElement previewButton;

	@FindBy(xpath = "//*[@id=\"app\"]/div[8]/div/div/nav/div/a/div/i")
	WebElement exitButton;

	@FindBy(xpath = "//*[@id=\"context-delete-257\"]/div/i")
	WebElement deleteButton;
	
	@FindBy(id = "context-download-dialog-yes-402")
	WebElement deleteButtonYes;
	
	@FindBy(id = "context-download-dialog-no-402")
	WebElement deleteButtonNo;
	
	@FindBy(id = "add-new-invoice")
	WebElement addNewInvoices;

	public InvoicesPage(WebDriver driver) {
		super(driver);

	}
	
	public String invoiceVerify() {
		return invoicesListText.getText();
	}
	
	public void selectClient() {
		clientList.click();
		ivanMarkovic.click();
	}
	
	public void selectFromDate1() {
		fromDate.click();
		date1.click();
		from_ok.click();
	}
	
	public void selectFromDate24() {
		fromDate.click();
		fromLastMonth.click();
		date24.click();
		from_ok.click();
	}
	
	public void selectFromDate8() {
		fromDate.click();
		date8.click();
		from_ok.click();
	}
	
	public void selectToDate1() {
		toDate.click();
		dateTo1.click();
		to_ok.click();
	}
	
	public void thisMonthButton() {
		monthButton.click();
		thisMonth.click();
	}
	
	public void lastMonthButton() {
		monthButton.click();
		thisMonth.click();
	}
	
	public void resetDateButton() {
		monthButton.click();
		resetDates.click();
	}
	
	public void clickRefreshButton() {
		refresh.click();
	}
	
	public void changeStatusSent() {
		changeStatusButton.click();
		changeStatusDropDown.click();
		sent.click();
		sentYes.click();
		
	}
	
	public void clickPreview() {
		optionsButton.click();
		previewButton.click();
		exitButton.click();
	}
	
	public void clickDeleteYes() {
		optionsButton.click();
		deleteButton.click();
		deleteButtonYes.click();
		
	}
	
	public void clickDeleteNo() {
		optionsButton.click();
		deleteButton.click();
		deleteButtonNo.click();
	}
	
	
	
	

}
