package Tests;

import org.testng.annotations.Test;

import Pages.AddNewInvoicesPage;
import Pages.LoginPage;

public class AddNewInvoicesTests extends Browser {

	@Test(priority = 9)
	public void emptyInvoice() {

		LoginPage login = new LoginPage(driver);
		AddNewInvoicesPage newInv = new AddNewInvoicesPage(driver);

		driver.get("http://app.invoice-factory.source-code.rs/login");

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

		driver.get("http://app.invoice-factory.source-code.rs/invoices/form");

		newInv.clickSave();

	}

	@Test(priority = 10)
	public void withoutTitle() {

		LoginPage login = new LoginPage(driver);
		AddNewInvoicesPage newInv = new AddNewInvoicesPage(driver);

		driver.get("http://app.invoice-factory.source-code.rs/login");

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

		newInv.clickDropDownTo();

		newInv.clickDropDownFrom();

		newInv.clickBasis("456");

		newInv.clickCurrency();

		newInv.selectBankField();

		newInv.clickSave();

		System.out.println(
				"The title field is required. | The subtotal field is required. | The total field is required.");

	}

	@Test(priority = 11)
	public void cancelButton() {

		LoginPage login = new LoginPage(driver);
		AddNewInvoicesPage newInv = new AddNewInvoicesPage(driver);

		driver.get("http://app.invoice-factory.source-code.rs/login");

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

		newInv.clickDropDownTo();

		newInv.clickDropDownFrom();

		newInv.clickBasis("456");

		newInv.clickCurrency();

		newInv.selectBankField();

		newInv.clickCancel();
	}

	@Test(priority = 12)
	public void backButton() {

		LoginPage login = new LoginPage(driver);
		AddNewInvoicesPage newInv = new AddNewInvoicesPage(driver);

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

		driver.get("http://app.invoice-factory.source-code.rs/login");

		newInv.clickBack();

	}
	
	@Test(priority = 13)
	public void logoutButton() {
		
		LoginPage login = new LoginPage(driver);
		AddNewInvoicesPage newInv = new AddNewInvoicesPage(driver);

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

		driver.get("http://app.invoice-factory.source-code.rs/login");
		
		newInv.clickLogout();
	}

}
