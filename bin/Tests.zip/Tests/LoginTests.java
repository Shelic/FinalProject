package Tests;

import org.testng.annotations.Test;

import Pages.LoginPage;

public class LoginTests extends Browser {

	@Test(priority = 0)
	public void invalidLogin() {

		LoginPage login = new LoginPage(driver);

		driver.get("http://app.invoice-factory.source-code.rs/login");

		login.fillInputs("marijanaselic@gmail.com", "");
		login.clickLogin();

		login.fillInputs(" ", "");
		login.clickLogin();

		login.fillInputs("", "qwe123");
		login.clickLogin();

	}

	@Test(priority = 1)
	public void incorectLogin() {

		LoginPage login = new LoginPage(driver);

		login.fillInputs("hfsjkdfkfh@gmail.com", "qwe123");
		login.clickLogin();

		login.fillInputs("marijanaselic@gmail.com", "ksfjlkss");
		login.clickLogin();
	}

	@Test(priority = 2)
	public void passwordCheck() {

		LoginPage login = new LoginPage(driver);

		login.fillInputs("", "12h5g");
		login.clickLogin();

		login.fillInputs("", "kfjug1458ghuj4745juik");
		login.clickLogin();

		login.clickVisibilityButton();

	}

	@Test(priority = 3)
	public void validLogin() {

		LoginPage login = new LoginPage(driver);

		login.fillInputs("marijanaselic@gmail.com", "qwe123");
		login.clickLogin();

	}

}
