package Tests;

import org.testng.annotations.Test;

public class InvoicesTests extends Browser  {
  @Test
  public void f() {
  }
}
